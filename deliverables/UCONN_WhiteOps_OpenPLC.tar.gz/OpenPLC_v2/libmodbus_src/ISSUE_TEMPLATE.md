### libmodbus version

### Operating system

### Description of the Modbus network (server, client, links, etc)

### Expected behavior

### Actual behavior

### Steps to reproduce the behavior (commands or source code)

### libmodbus output with debug mode enabled
